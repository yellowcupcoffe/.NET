﻿using System;

class Question
{
    public string questionText;
    public string optionA;
    public string optionB;
    public string optionC;
    public string optionD;
    public char correctAnswer;

    public void DisplayQuestion()
    {
        Console.WriteLine("\n" + questionText);
        Console.WriteLine("A. " + optionA);
        Console.WriteLine("B. " + optionB);
        Console.WriteLine("C. " + optionC);
        Console.WriteLine("D. " + optionD);
    }

    public bool CheckAnswer(char userAnswer)
    {
        return Char.ToUpper(userAnswer) == correctAnswer;
    }
}

class Program
{
    static void Main()
    {
        int score = 0;

        Question[] quiz = new Question[10];

        // Question 1
        quiz[0] = new Question();
        quiz[0].questionText = "What is the capital of India?";
        quiz[0].optionA = "Mumbai";
        quiz[0].optionB = "Delhi";
        quiz[0].optionC = "Chennai";
        quiz[0].optionD = "Kolkata";
        quiz[0].correctAnswer = 'B';

        // Question 2
        quiz[1] = new Question();
        quiz[1].questionText = "Which language is used in .NET?";
        quiz[1].optionA = "C#";
        quiz[1].optionB = "Python";
        quiz[1].optionC = "PHP";
        quiz[1].optionD = "Swift";
        quiz[1].correctAnswer = 'A';

        // Question 3
        quiz[2] = new Question();
        quiz[2].questionText = "Which planet is known as Red Planet?";
        quiz[2].optionA = "Earth";
        quiz[2].optionB = "Mars";
        quiz[2].optionC = "Venus";
        quiz[2].optionD = "Jupiter";
        quiz[2].correctAnswer = 'B';

        // Question 4
        quiz[3] = new Question();
        quiz[3].questionText = "Which keyword is used to create object in C#?";
        quiz[3].optionA = "create";
        quiz[3].optionB = "class";
        quiz[3].optionC = "new";
        quiz[3].optionD = "object";
        quiz[3].correctAnswer = 'C';

        // Question 5
        quiz[4] = new Question();
        quiz[4].questionText = "What is 10 + 20?";
        quiz[4].optionA = "10";
        quiz[4].optionB = "20";
        quiz[4].optionC = "40";
        quiz[4].optionD = "30";
        quiz[4].correctAnswer = 'D';

        // Question 6
        quiz[5] = new Question();
        quiz[5].questionText = "Which symbol is used for comments in C#?";
        quiz[5].optionA = "//";
        quiz[5].optionB = "##";
        quiz[5].optionC = "**";
        quiz[5].optionD = "<!--";
        quiz[5].correctAnswer = 'A';

        // Question 7
        quiz[6] = new Question();
        quiz[6].questionText = "Which datatype stores decimal numbers?";
        quiz[6].optionA = "int";
        quiz[6].optionB = "char";
        quiz[6].optionC = "double";
        quiz[6].optionD = "bool";
        quiz[6].correctAnswer = 'C';

        // Question 8
        quiz[7] = new Question();
        quiz[7].questionText = "Who developed C#?";
        quiz[7].optionA = "Google";
        quiz[7].optionB = "Microsoft";
        quiz[7].optionC = "Apple";
        quiz[7].optionD = "IBM";
        quiz[7].correctAnswer = 'B';

        // Question 9
        quiz[8] = new Question();
        quiz[8].questionText = "Which loop runs at least once?";
        quiz[8].optionA = "for";
        quiz[8].optionB = "while";
        quiz[8].optionC = "do-while";
        quiz[8].optionD = "foreach";
        quiz[8].correctAnswer = 'C';

        // Question 10
        quiz[9] = new Question();
        quiz[9].questionText = "Which operator is used for equality check?";
        quiz[9].optionA = "=";
        quiz[9].optionB = "!=";
        quiz[9].optionC = "==";
        quiz[9].optionD = "++";
        quiz[9].correctAnswer = 'C';

        // Quiz Logic
        for (int i = 0; i < quiz.Length; i++)
        {
            quiz[i].DisplayQuestion();

            Console.Write("Enter Your Answer: ");
            char answer = Convert.ToChar(Console.ReadLine());

            if (quiz[i].CheckAnswer(answer))
            {
                Console.WriteLine("Correct!");
                score++;
            }
            else
            {
                Console.WriteLine("Wrong!");
            }
        }

        Console.WriteLine("\nFinal Score = " + score + "/10");

        Console.ReadLine();
    }
}