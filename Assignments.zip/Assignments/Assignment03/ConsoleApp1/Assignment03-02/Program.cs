﻿using System;

// Interface
interface ILibrary
{
    void AddBook();
    void IssueBook();
    void ReturnBook();
    void DisplayBooks();
}

// Library Class
class Library : ILibrary
{
    string[] books = new string[100];
    bool[] issued = new bool[100];
    int count = 0;

    // Add Book
    public void AddBook()
    {
        Console.Write("Enter Book Name: ");
        books[count] = Console.ReadLine();

        issued[count] = false;
        count++;

        Console.WriteLine("Book Added Successfully!");
    }

    // Display Books
    public void DisplayBooks()
    {
        Console.WriteLine("\n===== Library Books =====");

        if (count == 0)
        {
            Console.WriteLine("No Books Available.");
            return;
        }

        for (int i = 0; i < count; i++)
        {
            Console.Write(i + 1 + ". " + books[i]);

            if (issued[i])
                Console.WriteLine("  --> Issued");
            else
                Console.WriteLine("  --> Available");
        }
    }

    // Issue Book
    public void IssueBook()
    {
        DisplayBooks();

        Console.Write("\nEnter Book Number to Issue: ");
        int choice = Convert.ToInt32(Console.ReadLine());

        if (choice <= count && choice > 0)
        {
            if (issued[choice - 1] == false)
            {
                issued[choice - 1] = true;
                Console.WriteLine("Book Issued Successfully!");
            }
            else
            {
                Console.WriteLine("Book Already Issued.");
            }
        }
        else
        {
            Console.WriteLine("Invalid Book Number.");
        }
    }

    // Return Book
    public void ReturnBook()
    {
        DisplayBooks();

        Console.Write("\nEnter Book Number to Return: ");
        int choice = Convert.ToInt32(Console.ReadLine());

        if (choice <= count && choice > 0)
        {
            if (issued[choice - 1] == true)
            {
                issued[choice - 1] = false;
                Console.WriteLine("Book Returned Successfully!");
            }
            else
            {
                Console.WriteLine("This Book Was Not Issued.");
            }
        }
        else
        {
            Console.WriteLine("Invalid Book Number.");
        }
    }
}

// Main Program
class Program
{
    static void Main()
    {
        Library lib = new Library();

        int choice;

        do
        {
            Console.WriteLine("\n===== COLLEGE LIBRARY MENU =====");
            Console.WriteLine("1. Add Book");
            Console.WriteLine("2. Display Books");
            Console.WriteLine("3. Issue Book");
            Console.WriteLine("4. Return Book");
            Console.WriteLine("5. Exit");

            Console.Write("Enter Your Choice: ");
            choice = Convert.ToInt32(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    lib.AddBook();
                    break;

                case 2:
                    lib.DisplayBooks();
                    break;

                case 3:
                    lib.IssueBook();
                    break;

                case 4:
                    lib.ReturnBook();
                    break;

                case 5:
                    Console.WriteLine("Exiting Application...");
                    break;

                default:
                    Console.WriteLine("Invalid Choice.");
                    break;
            }

        } while (choice != 5);

        Console.ReadLine();
    }
}