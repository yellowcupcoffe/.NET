﻿using System;

class ATMAccount
{
    private int pin;
    private double balance;

    // Property with Validation
    public int Pin
    {
        get
        {
            return pin;
        }

        set
        {
            // PIN must be 4 digits
            if (value >= 1000 && value <= 9999)
            {
                pin = value;
                Console.WriteLine("PIN Created Successfully!");
            }
            else
            {
                Console.WriteLine("Invalid PIN. PIN must be 4 digits.");
            }
        }
    }

    // Deposit Money
    public void Deposit()
    {
        Console.Write("Enter Amount to Deposit: ");
        double amount = Convert.ToDouble(Console.ReadLine());

        balance += amount;

        Console.WriteLine("Amount Deposited Successfully!");
    }

    // Withdraw Money
    public void Withdraw()
    {
        Console.Write("Enter Your PIN: ");
        int enteredPin = Convert.ToInt32(Console.ReadLine());

        if (enteredPin == pin)
        {
            Console.Write("Enter Amount to Withdraw: ");
            double amount = Convert.ToDouble(Console.ReadLine());

            if (amount <= balance)
            {
                balance -= amount;
                Console.WriteLine("Withdrawal Successful!");
            }
            else
            {
                Console.WriteLine("Insufficient Balance.");
            }
        }
        else
        {
            Console.WriteLine("Incorrect PIN.");
        }
    }

    // Check Balance
    public void CheckBalance()
    {
        Console.Write("Enter Your PIN: ");
        int enteredPin = Convert.ToInt32(Console.ReadLine());

        if (enteredPin == pin)
        {
            Console.WriteLine("Current Balance: " + balance);
        }
        else
        {
            Console.WriteLine("Incorrect PIN.");
        }
    }
}

class Program
{
    static void Main()
    {
        ATMAccount user = new ATMAccount();

        Console.WriteLine("===== ATM APPLICATION =====");

        // Create PIN
        Console.Write("Create 4-Digit PIN: ");
        user.Pin = Convert.ToInt32(Console.ReadLine());

        int choice;

        do
        {
            Console.WriteLine("\n===== MENU =====");
            Console.WriteLine("1. Deposit Money");
            Console.WriteLine("2. Withdraw Money");
            Console.WriteLine("3. Check Balance");
            Console.WriteLine("4. Exit");

            Console.Write("Enter Choice: ");
            choice = Convert.ToInt32(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    user.Deposit();
                    break;

                case 2:
                    user.Withdraw();
                    break;

                case 3:
                    user.CheckBalance();
                    break;

                case 4:
                    Console.WriteLine("Thank You!");
                    break;

                default:
                    Console.WriteLine("Invalid Choice.");
                    break;
            }

        } while (choice != 4);

        Console.ReadLine();
    }
}