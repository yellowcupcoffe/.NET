﻿using System;

class MedicalBot
{
    static void Main()
    {
        string symptom;
        int age;

        Console.WriteLine("===== Medical Bot =====");

        Console.Write("Enter Patient Age: ");
        age = Convert.ToInt32(Console.ReadLine());

        Console.Write("Enter Symptom (fever/cough/headache/cold): ");
        symptom = Console.ReadLine().ToLower();

        Console.WriteLine("\nPrescription:");

        if (symptom == "fever")
        {
            if (age < 12)
                Console.WriteLine("Take Paracetamol Syrup");
            else
                Console.WriteLine("Take Paracetamol Tablet");
        }
        else if (symptom == "cough")
        {
            if (age < 12)
                Console.WriteLine("Take Cough Syrup");
            else
                Console.WriteLine("Take Cough Tablets");
        }
        else if (symptom == "headache")
        {
            Console.WriteLine("Take Aspirin");
        }
        else if (symptom == "cold")
        {
            Console.WriteLine("Take Antihistamine");
        }
        else
        {
            Console.WriteLine("Please consult a doctor.");
        }

        Console.ReadLine();
    }
}