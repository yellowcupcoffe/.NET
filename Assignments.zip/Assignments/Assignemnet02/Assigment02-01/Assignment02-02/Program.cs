﻿using System;

class Program
{
    static void Main()
    {
        // int to double
        int number = 10;
        double d = Convert.ToDouble(number);

        // double to int
        double price = 99.99;
        int p = Convert.ToInt32(price);

        // string to int
        string age = "25";
        int a = Convert.ToInt32(age);

        // int to string
        int marks = 90;
        string m = Convert.ToString(marks);

        Console.WriteLine("Int to Double: " + d);
        Console.WriteLine("Double to Int: " + p);
        Console.WriteLine("String to Int: " + a);
        Console.WriteLine("Int to String: " + m);

        Console.ReadLine();
    }
}