﻿using System;

class Program
{
    static void Main()
    {
        double inches, centimeters;

        Console.Write("Enter height in inches: ");
        inches = Convert.ToDouble(Console.ReadLine());

        
        centimeters = inches * 2.54;

        Console.WriteLine("Height in centimeters = " + centimeters);

       
        if (centimeters < 150)
        {
            Console.WriteLine("Category: Short");
        }
        else if (centimeters >= 150 && centimeters < 170)
        {
            Console.WriteLine("Category: Average");
        }
        else
        {
            Console.WriteLine("Category: Tall");
        }

        Console.ReadLine();
    }
}