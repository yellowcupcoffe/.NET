﻿using System;

class Program
{
    static void main()
    {
        double area, radius;

        Console.Write("enter the value of radius");
        radius = Convert.ToDouble(Console.ReadLine());


        area = 3.14 * radius * radius;

        Console.Write("AREA OF CIRCLE IS: " + area);
        Console.ReadLine();

    }
}