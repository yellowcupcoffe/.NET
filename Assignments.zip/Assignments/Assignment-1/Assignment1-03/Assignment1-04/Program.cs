﻿using System;

class Program
{
    static void Main()
    {
        long totalSeconds;

        Console.Write("Enter number of seconds: ");
        totalSeconds = Convert.ToInt64(Console.ReadLine());

        long years = totalSeconds / (365 * 24 * 60 * 60);
        totalSeconds %= (365 * 24 * 60 * 60);

        long days = totalSeconds / (24 * 60 * 60);
        totalSeconds %= (24 * 60 * 60);

        long hours = totalSeconds / (60 * 60);
        totalSeconds %= (60 * 60);

        long minutes = totalSeconds / 60;

        long seconds = totalSeconds % 60;

        Console.WriteLine("Years   : " + years);
        Console.WriteLine("Days    : " + days);
        Console.WriteLine("Hours   : " + hours);
        Console.WriteLine("Minutes : " + minutes);
        Console.WriteLine("Seconds : " + seconds);

        Console.ReadLine();
    }
}