﻿using System;

class Program
{
    static void Main()
    {
        int number, nearestThousand;

        Console.Write("Enter a number: ");
        number = Convert.ToInt32(Console.ReadLine());

        nearestThousand = (int)Math.Round(number / 1000.0) * 1000;

        Console.WriteLine("Nearest Thousand = " + nearestThousand);

        Console.ReadLine();
    }
}